# License & Attribution – EzzAlgo v13

**Strategy Name:** EzzAlgo v13  
**Version:** v13  
**Release Date:** March 20, 2025  
**Author:** © Muhammad Reza Toyibah

---

## 📜 License

This script is released under the **Mozilla Public License 2.0 (MPL-2.0)**.

> You are free to use, modify, and distribute this code — for personal or commercial use — as long as you:
> - Include attribution to the original author,
> - Disclose any modifications you make to this file,
> - Keep derivative works under the same license if they use the same files.

🔗 Read the full license here: https://mozilla.org/MPL/2.0/

---

## 👤 Author & Primary Developer

- **Muhammad Reza Toyibah**  
  Creator and primary maintainer of EzzAlgo v13  
  Responsible for:
  - Entry logic for Renko & Open/Close setups  
  - Trend and sideways filters using ATR & RSI  
  - Dynamic Take Profit & Stop Loss handling  
  - Dashboard integration and visual engine

---

## 🤝 External Credits & Open Source Contributions

This project integrates and adapts snippets from open-source works with credit to:

### 🟢 Backtest Display Engine  
Adapted from: **The Art of Trading**  
- Source: [Hammers Stars Strategy](https://www.tradingview.com/script/t776tkZv-Hammers-Stars-Strategy/)

### 🟣 Performance Dashboard (Table Display)  
Inspired by: **@QuantNomad**  
- Profile: [QuantNomad on TradingView](https://www.tradingview.com/u/QuantNomad/)

---

## ⚠️ Disclaimer

This strategy is provided **"as-is"** without any warranties.  
Trading involves risk. The author is **not responsible for any financial losses** that may result from using or misusing this strategy, either in live or simulated markets.

---

## 💼 Commercial Use

Yes, you may offer this script for paid access, licensing, or commercial use — as long as the license terms are followed and attribution is preserved.

---

## 📝 Notes for Developers

If you fork, modify, or extend this strategy, you **must disclose your changes** and retain this LICENSE file in any distributed version.

Thank you for respecting the spirit of open-source sharing!
