# EzzAlgo v13 – Smart TradingView Strategy 🚀

**EzzAlgo v13** is a Pine Script-based rule-based strategy for TradingView that combines:

- Trend confirmation via ATR & RSI
- Entry setups using Open/Close or Renko logic
- Multi-level Take Profit & Stop Loss
- Modular backtest and performance dashboard

## 📂 Files Included

- `EzzAlgo-v13.pine` – main strategy script (annotated in Indonesian)
- `LICENSE.md` – license and attribution
- `README.md` – this file

## 🛠️ Usage

1. Copy the content of `EzzAlgo-v13.pine` into a new TradingView Pine Script editor window.
2. Adjust inputs and strategy parameters.
3. Click "Add to Chart" to test the strategy.
4. Use the backtest performance dashboard for insights.

---

© 2025 Muhammad Reza Toyibah. Licensed under MPL-2.0
